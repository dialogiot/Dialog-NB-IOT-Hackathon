#include "Adafruit_SleepyDog.h"

// Global instance of the main class for sketches to use.
WatchdogType Watchdog;
